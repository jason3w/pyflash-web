#ifndef __SPI_FLASH_H
#define __SPI_FLASH_H

#include "py32f0xx_ll_bus.h"
#include "py32f0xx_ll_gpio.h"
#include "py32f0xx_ll_spi.h"

#define SPIx                          SPI1
#define SPI_CLK_ENABLE()              LL_APB1_GRP2_EnableClock(LL_APB1_GRP2_PERIPH_SPI1)

//SPI_VCC_EN
#define SPI_VCC_EN_GPIO_CLK_ENABLE()  LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOB)
#define SPI_VCC_EN_PORT               GPIOB
#define SPI_VCC_EN_PIN                LL_GPIO_PIN_3

//CS
#define SPI_CS_GPIO_CLK_ENABLE()      LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOA)
#define SPI_CS_PORT                   GPIOA
#define SPI_CS_PIN                    LL_GPIO_PIN_15

//SCK
#define SPI_SCK_GPIO_CLK_ENABLE()     LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOA)
#define SPI_SCK_PORT                  GPIOA
#define SPI_SCK_PIN                   LL_GPIO_PIN_9

//MISO
#define SPI_MISO_GPIO_CLK_ENABLE()    LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOB)
#define SPI_MISO_PORT                 GPIOB
#define SPI_MISO_PIN                  LL_GPIO_PIN_4

//MOSI
#define SPI_MOSI_GPIO_CLK_ENABLE()    LL_IOP_GRP1_EnableClock(LL_IOP_GRP1_PERIPH_GPIOA)
#define SPI_MOSI_PORT                 GPIOA
#define SPI_MOSI_PIN                  LL_GPIO_PIN_8

#define SPI_GPIO_AF                   GPIO_AF0_SPI1

#define SPI_CS_H                      LL_GPIO_SetOutputPin(SPI_CS_PORT, SPI_CS_PIN)
#define SPI_CS_L                      LL_GPIO_ResetOutputPin(SPI_CS_PORT, SPI_CS_PIN)

#define SPI_ReadManufactureID         0x9F          //Read Manufacturer/device ID
#define SPI_DeviceID                  0x85          //Write Enable
#define SPI_WriteEnable               0x06          //Write Enable

#define P25X_BlockErase32             0x52          //Block Erase (32K bytes)
#define P25X_BlockErase64             0xD8          //Block Erase (64K bytes) 
#define P25X_ChipErase_C7h            0xC7          //Chip Erase C7h
#define P25X_ChipErase_60h            0x60          //Chip Erase 60h
#define P25X_PageErase_81h            0x81          //Page Erase 81h
#define P25X_SectorErase_20h          0x20          //Sector Erase (4K bytes)
#define P25X_ReadData                 0x03          //Read Array (low power)
#define P25X_PageProgram              0x02          //Page Program
#define P25X_Flash_Statu              0x05          //Flash Statu
#define P25X_Flash_WRCR               0x11          //Flash WRCR
#define P25X_Flash_RDCR               0x15          //Flash RDCR

#define SPI_8BYT_ADD                  0x01
#define SPI_16BYT_ADD                 0x02
#define SPI_24BYT_ADD                 0x03

#define SPI_FLASH_OnePageSize         1024
#define SPI_FLASH_OneSectorSize       4096

#define SPI_FLASH_ADDR_LENGTH         SPI_24BYT_ADD


void SPI_FLASH_Init(void);
void SPI_FLASH_Send_CMD(uint8_t instruction,uint32_t address,uint32_t addressSize,uint8_t csflags);
void SPI_FLASH_Write_Enable(void);
uint8_t SPI_FLASH_Write_CR(uint8_t CRData);
uint8_t FLASH_Get_CR(void);

uint8_t SPI_FLASH_ReadID(void);

void SPI_FLASH_Chip_Erase(void);
void SPI_FLASH_Page_Erase(uint32_t page_addr);
void SPI_FLASH_Erase_Sector(uint32_t sector_addr);

void SPI_FLASH_Read(uint8_t *pReadBuff, uint32_t StartAddr, uint32_t length);
void SPI_FLASH_Write(uint8_t *pWriteBuff,uint32_t StartAddr,uint32_t length);
void SPI_FLASH_FLASH_PageWrite(uint8_t *writebuff, uint32_t start_addr, uint16_t length);

void SPI_FLASH_Write_Addr_NoData(uint8_t *writebuff,uint32_t start_addr,uint32_t length);
#endif

