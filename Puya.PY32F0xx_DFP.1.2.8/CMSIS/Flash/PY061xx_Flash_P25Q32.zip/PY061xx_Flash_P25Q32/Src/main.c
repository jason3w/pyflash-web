/**
  ******************************************************************************
  * @file    main.c
  * @author  Puya Application Team
  * @version V1.0
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 Puya Semiconductor.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "FlashOS.h"        // FlashOS Structures
#include "spi_flash.h"
#include "py32f030xx_ll_Start_Kit.h"

/* Private define ------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
extern struct FlashDevice FlashDevice;
uint8_t data[4096];
/* Private user code ---------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
static void APP_Algo_Erase(void);
static void APP_Algo_Blank(void);
static void APP_Algo_Program(void);
static void APP_Algo_Verify(void);
static void APP_SetData(uint32_t* data, uint32_t addr, uint32_t size);



/**
  * @brief  Main program.
  * @retval int
  */
int main(void)
{
  APP_Algo_Erase();

//  APP_Algo_Blank();

  APP_Algo_Program();

  APP_Algo_Verify();

  while (1)
  {
  }
}

static void APP_SetData(uint32_t* data, uint32_t addr, uint32_t size)
{
  while (size)
  {
    *data = addr++;
    data++;
    size--;
  }
}

static void APP_Algo_Erase(void)
{
  if(Init(0,0,1))
  {
    while(1);
  }
#if 1
  if(EraseChip())
  {
    while(1);
  }
#else
  for(uint32_t addr = FlashDevice.DevAdr; addr<FlashDevice.DevAdr+FlashDevice.szDev; addr+=FlashDevice.sectors[0].szSector)
  {
    if(EraseSector(addr))
    {
      while(1);
    }
  }
#endif

  if(UnInit(1))
  {
    while(1);
  }
}

static void APP_Algo_Program(void)
{
  if(Init(0,0,2))
  {
    while(1);
  }

  for(uint32_t addr = FlashDevice.DevAdr; addr<FlashDevice.DevAdr+FlashDevice.szDev; addr+=FlashDevice.szPage)
  {
    APP_SetData((uint32_t*)data, addr/4, FlashDevice.szPage/4);

    if(ProgramPage(addr, FlashDevice.szPage, data))
    {
      while(1);
    }
  }

  if(UnInit(2))
  {
    while(1);
  }
}

static void APP_Algo_Verify(void)
{
  if(Init(0,0,3))
  {
    while(1);
  }

  for(uint32_t addr = FlashDevice.DevAdr; addr<FlashDevice.DevAdr+FlashDevice.szDev; addr+=FlashDevice.szPage)
  {
    APP_SetData((uint32_t*)data, addr/4, FlashDevice.szPage/4);
    if(Verify(addr,FlashDevice.szPage, data) != addr + FlashDevice.szPage)
    {
      while(1);
    }
  }

  if(UnInit(3))
  {
    while(1);
  }
}

static void APP_Algo_Blank(void)
{
  if(Init(0,0,4))
  {
    while(1);
  }

  for(uint32_t addr = FlashDevice.DevAdr; addr<FlashDevice.DevAdr+FlashDevice.szDev; addr+=FlashDevice.szPage)
  {
    if(BlankCheck(addr,FlashDevice.szPage, 0xFF))
    {
      while(1);
    }
  }

  if(UnInit(3))
  {
    while(1);
  }
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void APP_ErrorHandler(void)
{
  /* Infinite loop */
  while (1)
  {
  }
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     for example: printf("Wrong parameters value: file %s on line %d\r\n", file, line)  */
  /* Infinite loop */
  while (1)
  {
  }
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT Puya *****END OF FILE******************/
