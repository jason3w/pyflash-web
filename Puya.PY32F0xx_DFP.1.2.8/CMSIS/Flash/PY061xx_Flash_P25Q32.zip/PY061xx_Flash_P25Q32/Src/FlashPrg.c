/**************************************************************************//**
 * @file     FlashPrg.c
 * @brief    Flash Programming Functions adapted for New Device Flash
 * @version  V1.0.0
 * @date     10. January 2018
 ******************************************************************************/
/*
 * Copyright (c) 2010-2018 Arm Limited. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the License); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "FlashOS.h"        // FlashOS Structures
#include "spi_flash.h"

#define FLASH_READ_SIZE (256)

static void APP_SystemClockConfig(void);
/*
   Mandatory Flash Programming Functions (Called by FlashOS):
                int Init        (unsigned long adr,   // Initialize Flash
                                 unsigned long clk,
                                 unsigned long fnc);
                int UnInit      (unsigned long fnc);  // De-initialize Flash
                int EraseSector (unsigned long adr);  // Erase Sector Function
                int ProgramPage (unsigned long adr,   // Program Page Function
                                 unsigned long sz,
                                 unsigned char *buf);

   Optional  Flash Programming Functions (Called by FlashOS):
                int BlankCheck  (unsigned long adr,   // Blank Check
                                 unsigned long sz,
                                 unsigned char pat);
                int EraseChip   (void);               // Erase complete Device
      unsigned long Verify      (unsigned long adr,   // Verify Function
                                 unsigned long sz,
                                 unsigned char *buf);

       - BlanckCheck  is necessary if Flash space is not mapped into CPU memory space
       - Verify       is necessary if Flash space is not mapped into CPU memory space
       - if EraseChip is not provided than EraseSector for all sectors is called
*/

/*
 *  Initialize Flash Programming Functions
 *    Parameter:      adr:  Device Base Address
 *                    clk:  Clock Frequency (Hz)
 *                    fnc:  Function Code (1 - Erase, 2 - Program, 3 - Verify)
 *    Return Value:   0 - OK,  1 - Failed
 */

int Init(unsigned long adr, unsigned long clk, unsigned long fnc)
{
  /* Add your Code */
  APP_SystemClockConfig();
  
  SPI_FLASH_Init();
    
  if (SPI_DeviceID != SPI_FLASH_ReadID()) {
    return (1);
  }
    
  if (0 != SPI_FLASH_Write_CR(0x10))//1024BYTE
  {
    return (1);
  }
  return (0);                                  // Finished without Errors
}

/*
 *  De-Initialize Flash Programming Functions
 *    Parameter:      fnc:  Function Code (1 - Erase, 2 - Program, 3 - Verify)
 *    Return Value:   0 - OK,  1 - Failed
 */
int UnInit(unsigned long fnc)
{
    
    return 0;
}


/*
 *  Erase complete Flash Memory
 *    Return Value:   0 - OK,  1 - Failed
 */

int EraseChip(void)
{
  /* Add your Code */
  SPI_FLASH_Chip_Erase();
  return (0);                                  // Finished without Errors
}


/*
 *  Erase Sector in Flash Memory
 *    Parameter:      adr:  Sector Address
 *    Return Value:   0 - OK,  1 - Failed
 */

int EraseSector(unsigned long adr)
{
  /* Add your Code */
  SPI_FLASH_Erase_Sector(adr);
  return (0);                                  // Finished without Errors
}

/*
 *  Program Page in Flash Memory
 *    Parameter:      adr:  Page Start Address
 *                    sz:   Page Size
 *                    buf:  Page Data
 *    Return Value:   0 - OK,  1 - Failed
 */
int ProgramPage(unsigned long adr, unsigned long sz, unsigned char *buf)
{
  unsigned long wadr, wsz;
  unsigned char *wbuf;
  
  wadr = adr;
  wsz = sz;
  wbuf = buf;
  
  while (wsz) {
    SPI_FLASH_FLASH_PageWrite(wbuf, wadr, SPI_FLASH_OnePageSize);
    
    wadr += SPI_FLASH_OnePageSize;
    wsz -= SPI_FLASH_OnePageSize;
    wbuf += SPI_FLASH_OnePageSize;
  }
  
  return (0);                                  // Finished without Errors
}

/*
 *  Verify in Flash Memory
 *    Parameter:      adr:  Start Address
 *                    sz:   Size
 *                    buf:  Data
 *    Return Value:   Address+Size - OK,  Other - Failed
 */
unsigned long Verify(unsigned long adr, unsigned long sz, unsigned char *buf)
{
  unsigned long i;
  unsigned char rdata[FLASH_READ_SIZE];

  while (sz)
  {
    SPI_FLASH_Read(rdata, adr, FLASH_READ_SIZE);
    for (i = 0; i < FLASH_READ_SIZE; i++)
    {
      if (buf[i] != rdata[i])
      {
        return adr;
      }
    }
    adr += FLASH_READ_SIZE;
    sz -= FLASH_READ_SIZE;
    buf += FLASH_READ_SIZE;
  }
  return (adr);
}

/*
 *  Blank Check in Flash Memory
 *    Parameter:      adr:  Start Address
 *                    sz:   Size
 *                    pat:  Pattern to compare
 *    Return Value:   0 - OK,  1 - Failed
 */
int BlankCheck (unsigned long adr, unsigned long sz, unsigned char pat)
{
  return (1);
}

/**
  * @brief  System clock configuration function
  * @param  None
  * @retval None
  */
static void APP_SystemClockConfig(void)
{
  /* 24MHz 校准值存放地址： 0x1FFF 0F10 */
  MODIFY_REG(RCC->ICSCR, (RCC_ICSCR_HSI_FS|RCC_ICSCR_HSI_TRIM), HW32_REG(0x1FFF0F10));
  while (RCC_CR_HSIRDY != READ_BIT(RCC->CR, RCC_CR_HSIRDY));
  
//  SET_BIT(RCC->CR, RCC_CR_PLLON);
//  while (RCC_CR_PLLRDY != READ_BIT(RCC->CR, RCC_CR_PLLRDY));
  
//  SET_BIT(FLASH->ACR, FLASH_ACR_LATENCY);
  
//  /* 010: PLL CLK */
//  MODIFY_REG(RCC->CFGR, RCC_CFGR_SW, RCC_CFGR_SW_1);
//  while (RCC_CFGR_SWS_1 != READ_BIT(RCC->CFGR, RCC_CFGR_SWS));
}
