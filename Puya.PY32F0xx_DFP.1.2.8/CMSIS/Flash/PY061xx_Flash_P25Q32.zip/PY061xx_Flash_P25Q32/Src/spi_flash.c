#include "spi_flash.h"

uint32_t tempDATA = 0xFF;

void SPI_FLASH_Init(void)
{
  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

  SPI_CLK_ENABLE();

  SPI_CS_GPIO_CLK_ENABLE();
  SPI_VCC_EN_GPIO_CLK_ENABLE();
  SPI_SCK_GPIO_CLK_ENABLE();
  SPI_MISO_GPIO_CLK_ENABLE();
  SPI_MOSI_GPIO_CLK_ENABLE();

  //CS
  GPIO_InitStruct.Pin = SPI_CS_PIN;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_VERY_HIGH;
  LL_GPIO_Init(SPI_CS_PORT, &GPIO_InitStruct);
  SPI_CS_H;

//  //SPI_VCC_EN
//  GPIO_InitStruct.Pin = SPI_VCC_EN_PIN;
//  LL_GPIO_Init(SPI_VCC_EN_PORT, &GPIO_InitStruct);
//  LL_GPIO_ResetOutputPin(SPI_VCC_EN_PORT, SPI_VCC_EN_PIN);

  GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_UP;

  //SCK
  GPIO_InitStruct.Alternate = LL_GPIO_AF_10;
  GPIO_InitStruct.Pin = SPI_SCK_PIN;
  LL_GPIO_Init(SPI_SCK_PORT, &GPIO_InitStruct);
  
  //MISO
  GPIO_InitStruct.Alternate = LL_GPIO_AF_0;
  GPIO_InitStruct.Pin = SPI_MISO_PIN;
  LL_GPIO_Init(SPI_MISO_PORT, &GPIO_InitStruct);

  //MOSI
  GPIO_InitStruct.Alternate = LL_GPIO_AF_10;
  GPIO_InitStruct.Pin = SPI_MOSI_PIN;
  LL_GPIO_Init(SPI_MOSI_PORT, &GPIO_InitStruct);

  SET_BIT(RCC->APBRSTR1, RCC_APBRSTR2_SPI1RST);
  CLEAR_BIT(RCC->APBRSTR1, RCC_APBRSTR2_SPI1RST);

  /* SSM 1：使能软件从设备管理*/
  /* MSTR 1：配置为主设备 */
  SET_BIT(SPIx->CR1, SPI_CR1_SSM|SPI_CR1_SSI|SPI_CR1_MSTR|SPI_CR1_SPE);

  /* 波特率控制 000： fPCLK/2 */
  CLEAR_BIT(SPIx->CR1, SPI_CR1_BR);

  /* 1：如果 FIFO level 大于或者等于 1/4（8-bit）产生 RXNE */
  SET_BIT(SPIx->CR2, SPI_CR2_FRXTH);
  
  SET_BIT(RCC->APBENR2,RCC_APBENR2_SYSCFGEN);
  SET_BIT(RCC ->AHBENR ,RCC_AHBENR_DMAEN );
  SET_BIT(SPIx->CR2,SPI_CR2_TXDMAEN |SPI_CR2_RXDMAEN);
//  SET_BIT(DMA1_Channel1->CCR ,DMA_CCR_MINC|DMA_CCR_DIR);//M->P
//  SET_BIT(DMA1_Channel2->CCR ,DMA_CCR_PL |DMA_CCR_MINC);//P->M
  
  
  SET_BIT(DMA1_Channel1->CCR ,DMA_CCR_PSIZE_0|DMA_CCR_MSIZE_0|DMA_CCR_MINC|DMA_CCR_DIR);//M->P
  SET_BIT(DMA1_Channel2->CCR ,DMA_CCR_PL |DMA_CCR_PSIZE_0|DMA_CCR_MSIZE_0|DMA_CCR_MINC);//P->M
//   MODIFY_REG(SYSCFG ->CFGR3 ,0x1F1F,0x2201);
  MODIFY_REG(SYSCFG ->CFGR3 ,SYSCFG_CFGR3_DMA1_MAP|SYSCFG_CFGR3_DMA2_MAP,SYSCFG_CFGR3_DMA2_ACKLVL|SYSCFG_CFGR3_DMA2_MAP_1|SYSCFG_CFGR3_DMA1_MAP_0);
//  SET_BIT(DMA1_Channel1->CCR ,0x0290 );//M->P
//  SET_BIT(DMA1_Channel2->CCR ,0x3280 );//P->M

//  MODIFY_REG(SYSCFG ->CFGR3 ,0x1F1F,0x2201);

  DMA1_Channel1->CPAR =(uint32_t )&SPI1->DR;
  DMA1_Channel2->CPAR =(uint32_t )&SPI1->DR;
  SET_BIT (DMA1->IFCR,DMA_IFCR_CGIF1|DMA_IFCR_CTCIF1|DMA_IFCR_CHTIF1|DMA_IFCR_CGIF2|DMA_IFCR_CTCIF2|DMA_IFCR_CHTIF2);
  CLEAR_BIT (DMA1_Channel2->CCR ,1);
  CLEAR_BIT (DMA1_Channel1->CCR ,1);
  
  
}

void SPI_FLASH_Send_CMD(uint8_t instruction, uint32_t address, uint32_t addressSize, uint8_t csflags)
{
  __IO uint32_t i, size;
  __IO uint8_t data[4];

  SPI_CS_L;

  data[0] = instruction;
  size = addressSize + 1;

  for (i=0; i<addressSize; i++)
  {
    data[i+1] = address >> ((addressSize-i-1)*8);
  }

  for (i=0; i<size; i++)
  {
    while(0==LL_SPI_IsActiveFlag_TXE(SPIx));
    LL_SPI_TransmitData8(SPIx, data[i]);
    while(0==LL_SPI_IsActiveFlag_RXNE(SPIx));
    LL_SPI_ReceiveData8(SPIx);
  }

  if(csflags == 0)
  {
    SPI_CS_H;
  }
}

uint8_t FLASH_Get_Statu(void)
{
  uint8_t Statu[2] = {0};
  Statu[0] = P25X_Flash_Statu;
  SPI_CS_L;
  for (uint16_t i=0; i<2; i++)
  {
    while(0==LL_SPI_IsActiveFlag_TXE(SPIx));
    LL_SPI_TransmitData8(SPIx, Statu[i]);
    while(0==LL_SPI_IsActiveFlag_RXNE(SPIx));
    Statu[i] = LL_SPI_ReceiveData8(SPIx);
  }
  SPI_CS_H;
  return Statu[1];
}

/********************************************************************************************************
**函数信息 :void SPI_FLASH_Write_Enable()
**功能描述 :SPI_FLASH_Write_Enable函数
**输入参数 :
**输出参数 :
**    备注 :
********************************************************************************************************/
void SPI_FLASH_Write_Enable()
{
  SPI_FLASH_Send_CMD(SPI_WriteEnable,0,0,0);
  while((FLASH_Get_Statu() & 0x01) != 0x00);
}

uint8_t SPI_FLASH_Write_CR(uint8_t CRData)
{
  SPI_FLASH_Write_Enable();
  
  SPI_FLASH_Send_CMD(P25X_Flash_WRCR,0,0,1);
  SPI_FLASH_Send_CMD(CRData,0,0,0);
  
  while((FLASH_Get_Statu() & 0x01) != 0x00);
  
  return (CRData == FLASH_Get_CR()) ? 0 : 1;
}

uint8_t FLASH_Get_CR(void)
{
  uint8_t Statu[2] = {0};
  Statu[0] = P25X_Flash_RDCR;
  SPI_CS_L;
  for (uint16_t i=0; i<2; i++)
  {
    while(0==LL_SPI_IsActiveFlag_TXE(SPIx));
    LL_SPI_TransmitData8(SPIx, Statu[i]);
    while(0==LL_SPI_IsActiveFlag_RXNE(SPIx));
    Statu[i] = LL_SPI_ReceiveData8(SPIx);
  }
  SPI_CS_H;
  return Statu[1];
}


uint8_t SPI_FLASH_ReadID(void)
{
  uint8_t buf[3], *pbuf;
  uint8_t length = 3;
  
  pbuf = buf;
    
  while((FLASH_Get_Statu() & 0x01) != 0x00);
  SPI_FLASH_Send_CMD(SPI_ReadManufactureID, 0, 0, 1);

  while (length--)
  {
    while(0==LL_SPI_IsActiveFlag_TXE(SPIx));
    LL_SPI_TransmitData8(SPIx, 0x00);
    while(0==LL_SPI_IsActiveFlag_RXNE(SPIx));
    *pbuf++ = LL_SPI_ReceiveData8(SPIx);
  }

  SPI_CS_H;
  
  while((FLASH_Get_Statu() & 0x01) != 0x00);

  return buf[0];
}

/********************************************************************************************************
**函数信息 :void SPI_FLASH_Chip_Erase
**功能描述 :擦除P25QXX整个芯片的内容
**输入参数 :None
**输出参数 :None
**    备注 :None
********************************************************************************************************/
void SPI_FLASH_Chip_Erase()
{
  while((FLASH_Get_Statu() & 0x01) != 0x00);
  SPI_FLASH_Write_Enable();                     //SET WEL
  SPI_FLASH_Send_CMD(P25X_ChipErase_C7h,0,0,0); //chip erase
}

/********************************************************************************************************
**函数信息 :SPI_FLASH_Page_Erase(uint32_t page_addr)
**功能描述 :根据地址擦除该地址所在的整个page
**输入参数 :None
**输出参数 :None
**    备注 :None
********************************************************************************************************/
void SPI_FLASH_Page_Erase(uint32_t page_addr)
{
  while((FLASH_Get_Statu() & 0x01) != 0x00);
  SPI_FLASH_Write_Enable();
  SPI_FLASH_Send_CMD(P25X_PageErase_81h, page_addr, SPI_FLASH_ADDR_LENGTH, 0); //page erase
}

/********************************************************************************************************
**函数信息 :SPI_FLASH_Erase_Sector(uint32_t sector_addr)
**功能描述 :根据地址擦除该地址所在的整个Sector
**输入参数 :None
**输出参数 :None
**    备注 :None
********************************************************************************************************/
void SPI_FLASH_Erase_Sector(uint32_t sector_addr)
{
  while((FLASH_Get_Statu() & 0x01) != 0x00);
  SPI_FLASH_Write_Enable();
  SPI_FLASH_Send_CMD(P25X_SectorErase_20h, sector_addr, SPI_FLASH_ADDR_LENGTH,0); //page erase
}
/********************************************************************************************************
**函数信息 :SPI_FLASH_FLASH_PageWrite(uint8_t *databuff,uint32_t start_addr,uint16_t length)
**功能描述 :只能按页写入
**输入参数 :databuff:写入的数据
                        start_addr:起始地址 length：写入长度
**输出参数 :
**    备注 :
********************************************************************************************************/
void SPI_FLASH_FLASH_PageWrite(uint8_t *writebuff, uint32_t start_addr, uint16_t length)
{
  while((FLASH_Get_Statu() & 0x01) != 0x00);

  SPI_FLASH_Write_Enable();

  SPI_FLASH_Send_CMD(P25X_PageProgram, start_addr, SPI_FLASH_ADDR_LENGTH, 1);

  CLEAR_BIT(SPIx->CR2, SPI_CR2_FRXTH);
  
  CLEAR_BIT (DMA1_Channel1->CCR ,1);
  CLEAR_BIT (DMA1_Channel2->CCR ,1);
  SET_BIT (DMA1->IFCR,DMA_IFCR_CGIF1|DMA_IFCR_CTCIF1|DMA_IFCR_CHTIF1|DMA_IFCR_CGIF2|DMA_IFCR_CTCIF2|DMA_IFCR_CHTIF2);
  DMA1_Channel1->CNDTR =(length)>>1;
  DMA1_Channel1->CMAR =(uint32_t )writebuff;
  SET_BIT(DMA1_Channel1->CCR,DMA_CCR_MINC);
  
  DMA1_Channel2->CNDTR =length>>1;
  DMA1_Channel2->CMAR =(uint32_t )&tempDATA;
  CLEAR_BIT(DMA1_Channel2->CCR,DMA_CCR_MINC);
  
  SET_BIT (DMA1_Channel2->CCR ,1);
  CLEAR_BIT (DMA1_Channel2->CCR ,1);
  DMA1_Channel2->CNDTR =length>>1;
  
  SET_BIT (DMA1_Channel2->CCR ,1);
  SET_BIT (DMA1_Channel1->CCR ,1);
  while((DMA1->ISR&DMA_ISR_TCIF1)!=DMA_ISR_TCIF1);
  while((DMA1->ISR&DMA_ISR_TCIF2)!=DMA_ISR_TCIF2);
  
  SET_BIT (DMA1->IFCR,DMA_IFCR_CGIF1|DMA_IFCR_CTCIF1|DMA_IFCR_CHTIF1|DMA_IFCR_CGIF2|DMA_IFCR_CTCIF2|DMA_IFCR_CHTIF2);
  CLEAR_BIT (DMA1_Channel1->CCR ,1);
  CLEAR_BIT (DMA1_Channel2->CCR ,1);
//  
  
//  while (length--)
//  {
//    while(0==LL_SPI_IsActiveFlag_TXE(SPIx));
//    LL_SPI_TransmitData8(SPIx, *writebuff++);
//    while(0==LL_SPI_IsActiveFlag_RXNE(SPIx));
//    LL_SPI_ReceiveData8(SPIx);
//  }
  SET_BIT(SPIx->CR2, SPI_CR2_FRXTH);
  SPI_CS_H;
}


/********************************************************************************************************
**函数信息 :SPI_FLASH_Write_Addr_NoData(uint8_t *databuff,uint32_t start_addr,uint32_t length)
**功能描述 :默认写该page无数据，直接写入，必须确保所写的地址范围内数据全为0xff，否则写不进去
            具有自动换页功能
**输入参数 :databuff:写入的数据
                        start_addr:起始地址 end_addr：结束地址
**输出参数 :
**    备注 :
********************************************************************************************************/
void SPI_FLASH_Write_Addr_NoData(uint8_t *writebuff,uint32_t start_addr,uint32_t length)
{
  uint8_t  Write_Num_Of_Page = 0;            //写入的数据又多少个整页
  uint8_t  Write_Data_Of_Remain = 0;        //不满一页剩下的数据
  uint8_t  WriteAddr = 0;             //首地址是否页对齐
  uint8_t  Flash_Data_Of_Remain = 0;                   //从起始地址start_addr开始，这一页还可以写入的数据量
  uint8_t  temp = 0;

  WriteAddr =  start_addr % SPI_FLASH_OnePageSize;                           //若start_addr是256的整数倍，则start_addr就是页的首地址，若不是，需要从页的中间开始写入
  Flash_Data_Of_Remain = SPI_FLASH_OnePageSize - WriteAddr;                                              //差Flash_Data_Of_Remain个数据值，刚好可以对齐到页地址
  Write_Num_Of_Page = length / SPI_FLASH_OnePageSize;                                     //计算出有多少个整页
  Write_Data_Of_Remain = length % SPI_FLASH_OnePageSize;                                     //mod运算求余，计算出剩余不满一页的字节数

  if(WriteAddr == 0)                                    //写入地址的起始地址刚好页对齐
  {
    if(Write_Num_Of_Page == 0)                            //写入的数据长度没有超过一页
    {
      SPI_FLASH_FLASH_PageWrite(writebuff,start_addr,length);
    }
    else                                                            //写入的数据长度超过了一页
    {
      //先把整数页都写了
      while (Write_Num_Of_Page--)
      {
        SPI_FLASH_FLASH_PageWrite(writebuff, start_addr, SPI_FLASH_OnePageSize);
        start_addr +=  SPI_FLASH_OnePageSize;
        writebuff += SPI_FLASH_OnePageSize;
      }
      //再把多余的不满一页，剩下的数据写完,若正好整数页，则不用写剩下的页
      if(Write_Data_Of_Remain > 0)
      {
        SPI_FLASH_FLASH_PageWrite(writebuff, start_addr, Write_Data_Of_Remain);
      }
    }
  }
  else                                        //写入地址的起始地址与SPI_FLASH_OnePageSize不对齐
  {
    if(Write_Num_Of_Page == 0)                            //写入的数据长度没有超过一页
    {
      if (Write_Data_Of_Remain > Flash_Data_Of_Remain)         //当前页剩余的Flash_Data_Of_Remain个位置比Write_Data_Of_Remain小，当前页写不完，需要跨后一页
      {
        temp = Write_Data_Of_Remain - Flash_Data_Of_Remain;

        /*先写满当前页*/
        SPI_FLASH_FLASH_PageWrite(writebuff, start_addr, Flash_Data_Of_Remain);
        start_addr +=  Flash_Data_Of_Remain;
        writebuff += Flash_Data_Of_Remain;

        /*再写剩余的数据*/
        SPI_FLASH_FLASH_PageWrite(writebuff, start_addr, temp);
      }
      else /*当前页剩余的Flash_Data_Of_Remain个位置能写完Write_Data_Of_Remain个数据*/
      {
        SPI_FLASH_FLASH_PageWrite(writebuff, start_addr, length);
      }
    }
    else                                                //写入的数据长度超过一页
    {
      length = length - Flash_Data_Of_Remain;                            //把要写入的数据总长度减去起始地址那一页剩余的数据长度

      Write_Num_Of_Page = length / SPI_FLASH_OnePageSize;                                     //计算出剩余数据有多少个整页
      Write_Data_Of_Remain = length % SPI_FLASH_OnePageSize;                                     //mod运算求余，计算出剩余不满一页的字节数
      //把起始地址那页填充满
      SPI_FLASH_FLASH_PageWrite(writebuff, start_addr, Flash_Data_Of_Remain);
      start_addr += Flash_Data_Of_Remain;
      writebuff += Flash_Data_Of_Remain;

      //把后面整页的数据写入
      while (Write_Num_Of_Page--)
      {
        SPI_FLASH_FLASH_PageWrite(writebuff, start_addr, SPI_FLASH_OnePageSize);
        start_addr +=  SPI_FLASH_OnePageSize;
        writebuff += SPI_FLASH_OnePageSize;
      }
      //再把多余的不满一页，剩下的数据写完,若正好整数页，则不用写剩下的页
      if(Write_Data_Of_Remain > 0)
      {
        SPI_FLASH_FLASH_PageWrite(writebuff, start_addr, Write_Data_Of_Remain);
      }
    }

  }
}
/********************************************************************************************************
**函数信息 :SPI_FLASH_Write(uint8_t *pWriteBuff,uint32_t StartAddr,uint32_t length)
**功能描述 :该函数带擦除操作
**输入参数 :pWriteBuff:写入的数据
                        StartAddr:起始地址 length：写入数据长度
**输出参数 :
**    备注 :
********************************************************************************************************/
void SPI_FLASH_Write(uint8_t *pWriteBuff,uint32_t StartAddr,uint32_t length)
{
  uint8_t  NumOfPage = 0;                            //写入的数据有多少个整页
  uint8_t     DataOfRemain = 0;                    //最后不满一页剩下的数据个数
  uint8_t  AddrOfPage = 0;                         //首地址是否页对齐
  uint8_t  PageOfRemain = 0;                   //从起始地址start_addr开始，这一页还可以写入的数据量
  uint32_t  StartAddrOfPage;                    //写的第一页的起始地址
  uint8_t  PageBuffer[SPI_FLASH_OnePageSize];
  uint8_t  i;

  AddrOfPage =  StartAddr % SPI_FLASH_OnePageSize;      //若start_addr是256的整数倍，则start_addr就是页的首地址，若不是，需要从页的中间开始写入
  PageOfRemain = SPI_FLASH_OnePageSize - AddrOfPage;    //差PageOfRemain个数据值，刚好可以对齐到页地址
  NumOfPage = length / SPI_FLASH_OnePageSize;           //计算出有多少个整页
  DataOfRemain = length % SPI_FLASH_OnePageSize;        //mod运算求余，计算出剩余不满一页的字节数
  StartAddrOfPage = StartAddr - AddrOfPage;

  if(AddrOfPage == 0)                                   //写入地址的起始地址刚好页对齐
  {
    if(NumOfPage == 0)                                  //写入的数据长度没有超过一页
    {
      SPI_FLASH_Page_Erase(StartAddr);
      SPI_FLASH_FLASH_PageWrite(pWriteBuff,StartAddr,length);
    }
    else                                                            //写入的数据长度超过了一页
    {
      //先把整数页都写了
      while (NumOfPage--)
      {
        SPI_FLASH_Page_Erase(StartAddr);
        SPI_FLASH_FLASH_PageWrite(pWriteBuff, StartAddr, SPI_FLASH_OnePageSize);
        StartAddr +=  SPI_FLASH_OnePageSize;
        pWriteBuff += SPI_FLASH_OnePageSize;
      }
      //若整数页写完还剩不到一页没写完的数据，则再写剩下的
      if(DataOfRemain > 0)
      {
        SPI_FLASH_Page_Erase(StartAddr);
        SPI_FLASH_FLASH_PageWrite(pWriteBuff, StartAddr, DataOfRemain);
      }
    }
  }
  else                                                    //写入地址的起始地址不对齐页，需要将第一页的内容读出备份，再一起写入
  {
    if(NumOfPage == 0)                    //写入的数据长度大小没有超过一页，因为首地址不确定，可能需要跨页写
    {
      //把起始地址那页填充满
      SPI_FLASH_Read(PageBuffer,StartAddrOfPage,SPI_FLASH_OnePageSize);
      SPI_FLASH_Page_Erase(StartAddr);

      for(i=0; i<PageOfRemain; i++)                                                                           //备份
      {
        PageBuffer[i+AddrOfPage]= pWriteBuff[i];
      }

      pWriteBuff = pWriteBuff + i;
      SPI_FLASH_FLASH_PageWrite(PageBuffer, StartAddrOfPage, SPI_FLASH_OnePageSize);
      StartAddr =  StartAddrOfPage + SPI_FLASH_OnePageSize;
      //在下一页，再写剩余的数据
      if (DataOfRemain > PageOfRemain)                                 //当前页剩余的PageOfRemain个存储位置比DataOfRemain小，当前页写不完，需要跨后一页
      {
        SPI_FLASH_Page_Erase(StartAddr);
        SPI_FLASH_FLASH_PageWrite(pWriteBuff, StartAddr,length- PageOfRemain);
      }
    }
    else                                                                                            //写入的数据长度超过一页
    {
      length = length - PageOfRemain;                                    //把要写入的数据总长度减去起始地址那一页剩余的数据长度

      NumOfPage = length / SPI_FLASH_OnePageSize;              //计算出剩余数据有多少个整页
      DataOfRemain = length % SPI_FLASH_OnePageSize;            //mod运算求余，计算出剩余不满一页的字节数
      //把起始地址那页填充满
      SPI_FLASH_Read(PageBuffer,StartAddrOfPage,SPI_FLASH_OnePageSize);
      SPI_FLASH_Page_Erase(StartAddr);

      for(i=0; i<PageOfRemain; i++)                                           //备份
      {
        PageBuffer[i+AddrOfPage]= pWriteBuff[i];
      }

      pWriteBuff = pWriteBuff + i;

      SPI_FLASH_FLASH_PageWrite(PageBuffer, StartAddrOfPage, SPI_FLASH_OnePageSize);
      StartAddr = StartAddrOfPage + SPI_FLASH_OnePageSize;

      //把后面整页的数据写入
      while (NumOfPage--)
      {
        SPI_FLASH_Page_Erase(StartAddr);
        SPI_FLASH_FLASH_PageWrite(pWriteBuff, StartAddr, SPI_FLASH_OnePageSize);
        StartAddr +=  SPI_FLASH_OnePageSize;
        pWriteBuff += SPI_FLASH_OnePageSize;
      }
      //再把多余的不满一页，剩下的数据写完,若正好整数页，则不用写剩下的页
      if(DataOfRemain > 0)
      {
        SPI_FLASH_Page_Erase(StartAddr);
        SPI_FLASH_FLASH_PageWrite(pWriteBuff, StartAddr, DataOfRemain);
      }
    }
  }
}
/********************************************************************************************************
**函数信息 :void SPI_FLASH_Read(uint8_t *pReadBuff,uint32_t StartAddr,uint32_t length)
**功能描述 :SPI_FLASH_Read函数
**输入参数 :pReadBuff:读出的数据
                        StartAddr:起始地址 length：长度
**输出参数 :
**    备注 :
********************************************************************************************************/
void SPI_FLASH_Read(uint8_t *pReadBuff, uint32_t StartAddr, uint32_t length)
{
  while((FLASH_Get_Statu() & 0x01) != 0x00);
  SPI_FLASH_Send_CMD(P25X_ReadData, StartAddr, SPI_FLASH_ADDR_LENGTH, 1);

  CLEAR_BIT (DMA1_Channel1->CCR ,1);
  CLEAR_BIT (DMA1_Channel2->CCR ,1);
  SET_BIT (DMA1->IFCR,DMA_IFCR_CGIF1|DMA_IFCR_CTCIF1|DMA_IFCR_CHTIF1|DMA_IFCR_CGIF2|DMA_IFCR_CTCIF2|DMA_IFCR_CHTIF2);
  
  CLEAR_BIT(SPIx->CR2, SPI_CR2_FRXTH);
  DMA1_Channel1->CNDTR =(length)>>1;
  DMA1_Channel1->CMAR =(uint32_t )&tempDATA;
  CLEAR_BIT(DMA1_Channel1->CCR,DMA_CCR_MINC);
  
  DMA1_Channel2->CNDTR =length>>1;
  DMA1_Channel2->CMAR =(uint32_t )pReadBuff;
  SET_BIT(DMA1_Channel2->CCR,DMA_CCR_MINC);
  SET_BIT (DMA1_Channel2->CCR ,1);
  CLEAR_BIT (DMA1_Channel2->CCR ,1);
  DMA1_Channel2->CNDTR =length>>1;
  
  SET_BIT (DMA1_Channel2->CCR ,1);
  SET_BIT (DMA1_Channel1->CCR ,1);
  while((DMA1->ISR&DMA_ISR_TCIF1)!=DMA_ISR_TCIF1);
  while((DMA1->ISR&DMA_ISR_TCIF2)!=DMA_ISR_TCIF2);
  
  SET_BIT (DMA1->IFCR,DMA_IFCR_CGIF1|DMA_IFCR_CTCIF1|DMA_IFCR_CHTIF1|DMA_IFCR_CGIF2|DMA_IFCR_CTCIF2|DMA_IFCR_CHTIF2);

  CLEAR_BIT (DMA1_Channel2->CCR ,1);
  CLEAR_BIT (DMA1_Channel1->CCR ,1);
  
//  while (length--)
//  {
//    while(0==LL_SPI_IsActiveFlag_TXE(SPIx));
//    LL_SPI_TransmitData8(SPIx, 0x00);
//    while(0==LL_SPI_IsActiveFlag_RXNE(SPIx));
//    *pReadBuff++ = LL_SPI_ReceiveData8(SPIx);
//  }
  
  SET_BIT(SPIx->CR2, SPI_CR2_FRXTH);
  SPI_CS_H;
}

/********************************************************************************************************
**函数信息 :SPI_FLASH_Write(uint8_t *databuff,uint32_t start_addr,uint32_t length)
**功能描述 :该函数带擦除操作，先读出要写入的扇区，擦除后再与新数据一起写入
**输入参数 :writebuff:写入的数据
                        start_addr:起始地址 length：写入长度
**输出参数 :
**    备注 :
********************************************************************************************************/
void SPI_FLASH_Write_Sector(uint8_t *writebuff,uint32_t start_addr,uint32_t length)
{
  uint8_t sector_buff[4096];
  uint32_t sector_pos;
  uint32_t sector_start_addr;
  uint16_t sector_offset,sector_remain;
  uint16_t i;

  sector_pos = start_addr/SPI_FLASH_OneSectorSize;                      //扇区地址
  sector_offset = start_addr%SPI_FLASH_OneSectorSize;                 //扇区内的偏移
  sector_remain = SPI_FLASH_OneSectorSize - sector_offset;     //扇区剩余空间大小
  sector_start_addr= sector_pos*SPI_FLASH_OneSectorSize;

  //第一个扇区
  SPI_FLASH_Read(sector_buff,sector_start_addr,SPI_FLASH_OneSectorSize);        //先把第一个扇区数据读出来
  for(i = 0; i<SPI_FLASH_OneSectorSize; i++)
  {
    if(sector_buff[i] ==0xff)
    {
      break;
    }
  }
  if(i<sector_remain)//需要擦除
  {
    SPI_FLASH_Erase_Sector(sector_start_addr);
    for(i=0; i<sector_remain; i++)               //复制
    {
      sector_buff[i+sector_offset]=writebuff[i];
    }
    SPI_FLASH_Write_Addr_NoData(sector_buff,sector_start_addr,SPI_FLASH_OneSectorSize);//写入整个扇区
    writebuff = writebuff + sector_remain;
    sector_start_addr = sector_start_addr +SPI_FLASH_OneSectorSize;
  }

  if(length > sector_remain) //如果要写入的数据长度大于扇区剩余的空间大小，就要跨扇区读写
  {
    uint32_t total_sectors;
    uint32_t last_sector_data;

    length = length - sector_remain;                            //把要写入的数据总长度减去起始地址那一扇区剩余的数据长度
    total_sectors = SPI_FLASH_OneSectorSize/length + 1;        //默认已经是跨扇区了，如果length小于4096还是要再写一个扇区
    last_sector_data =  SPI_FLASH_OneSectorSize% length;                                     //mod运算求余，计算出最后一个不满一个扇区的字节数


    if(last_sector_data>SPI_FLASH_OneSectorSize)        //数据超过两个扇区
    {
      //中间扇区
      while(total_sectors--)
      {
        SPI_FLASH_Erase_Sector(total_sectors);
        SPI_FLASH_Write_Addr_NoData(writebuff,sector_start_addr,SPI_FLASH_OneSectorSize);//写入整个扇区
        writebuff = writebuff + SPI_FLASH_OneSectorSize;
        sector_start_addr = sector_start_addr +SPI_FLASH_OneSectorSize;
      }
      //最后一个扇区
      SPI_FLASH_Read(sector_buff,sector_start_addr,SPI_FLASH_OneSectorSize);        //先把最后一个扇区数据读出来
      for(i = 0; i<SPI_FLASH_OneSectorSize; i++)
      {
        if(sector_buff[i] ==0xff)
        {
          break;
        }
      }
      if(i<sector_remain)//需要擦除
      {
        SPI_FLASH_Erase_Sector(sector_start_addr);
        for(i=0; i<sector_remain; i++)               //复制
        {
          sector_buff[i+sector_offset]=writebuff[i];
        }
        SPI_FLASH_Write_Addr_NoData(sector_buff,sector_start_addr,SPI_FLASH_OneSectorSize);//写入整个扇区
        writebuff = writebuff + sector_remain;
        sector_start_addr = sector_start_addr +SPI_FLASH_OneSectorSize;
      }
    }
    else
    {
      //最后一个扇区
    }
  }
}


